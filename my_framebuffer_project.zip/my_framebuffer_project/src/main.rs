// src/main.rs

#![no_std]
#![no_main]

// Import the bootloader’s entry point macro.
extern crate bootloader;
use bootloader::{entry_point, BootInfo};

mod framebuffer;
use framebuffer::{print, println};

entry_point!(kernel_main);

fn kernel_main(_boot_info: &'static BootInfo) -> ! {
    // Example output:
    print!("Hello, world!\nThis is a test.\n\\cBlue Blue Text\tIndented Text");
    
    loop {}
}

#[panic_handler]
fn panic(_info: &core::panic::PanicInfo) -> ! {
    loop {}
}
